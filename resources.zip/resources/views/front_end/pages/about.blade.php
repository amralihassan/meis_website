@extends('front_end.index')
@section('content')
    <section class="hero-wrap hero-wrap-2" style="background-image: url({{url('public/design/site/images/bg_2.jpg')}});">
        <div class="overlay"></div>
        <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
            <div class="col-md-9 ftco-animate text-center">
            <img src="{{asset('public/images/website/'.settingHelper()->logo)}}" style="width:75px;height:75px;margin-left: auto; margin-right: auto;">
            <h1 class="mb-2 bread">About Us</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="{{url('/home')}}">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>About us <i class="ion-ios-arrow-forward"></i></span></p>
            </div>
        </div>
        </div>
    </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 course d-lg-flex ftco-animate">
                    <div class="img" style="background-image: url({{ url('public/design/site/images/course-1.jpg') }});"></div>
                    <div class="text bg-light p-4">
                        <h3><a href="#">Vision</a></h3>
                        <p>We are and will be a school where design and social research drive approaches to studying issues of our time, such as democracy, urbanization, technological change, economic empowerment, sustainability, migration, and globalization. We will be the preeminent intellectual and creative school for effective engagement in a world that increasingly demands better-designed objects, communication, systems, and organizations to meet social needs</p>
                    </div>
                </div>
                <div class="col-md-6 course d-lg-flex ftco-animate">
                    <div class="img" style="background-image: url({{ url('public/design/site/images/course-2.jpg') }});"></div>
                    <div class="text bg-light p-4">
                        <h3><a href="#">Mission</a></h3>
                        <p>MEIS aims to contribute in creating a wonderful world by working on improving its student’s skills.</p>
                        <p>MEIS education respects national as well as international cultures and histories.</p>
                        <p>MEIS seeks to develop future leaders who are tolerant, reflective, creative and disciplined.</p>
                        <p>MEIS creates value through embracing all, teachers, students, in an atmosphere of genuine care and love.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('javascript')
<script src="{{url('public/design/site/js/jquery.min.js')}}"></script>
<script src="{{url('public/design/site/js/jquery-migrate-3.0.1.min.js')}}"></script>
@endsection
