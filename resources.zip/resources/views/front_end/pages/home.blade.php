@extends('front_end.index')
@section('content')
<section class="home-slider owl-carousel">
    <div class="slider-item" style="background-image:url('{{url('public/design/site/images/bg_1.jpg')}}');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
            <div class="col-md-8 text-center ftco-animate">
            <img src="{{asset('public/images/website/'.settingHelper()->logo)}}" style="width:100px;height:100px;margin-left: auto; margin-right: auto;">
            <h1 class="mb-4">Kids Are The Best <span>Explorers In The World</span></h1>
            {{--  <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3">Read More</a></p>  --}}
            </div>
        </div>
        </div>
    </div>

    <div class="slider-item" style="background-image:url({{url('public/design/site/images/bg_2.jpg')}});">
        <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
        <div class="col-md-8 text-center ftco-animate">
            <img src="{{asset('public/images/website/'.settingHelper()->logo)}}" style="width:100px;height:100px;margin-left: auto; margin-right: auto;">

          <h1 class="mb-4">Perfect Learned<span> For Your Child</span></h1>
          {{--  <p><a href="#" class="btn btn-secondary px-4 py-3 mt-3">Read More</a></p>  --}}
        </div>
      </div>
      </div>
    </div>
</section>

<section class="ftco-services ftco-no-pb">
    <div class="container-wrap">
        <div class="row no-gutters">
              <div class="col-md-3 d-flex services align-self-stretch pb-4 px-4 ftco-animate bg-primary">
                <div class="media block-6 d-block text-center">
                      <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-teacher"></span>
                      </div>
                      <div class="media-body p-2 mt-3">
                        <h3 class="heading">Etiquette</h3>
                        <p>Always try to be positive rather than negative when instructing you child.
                            Instead of asking them to don't do something, ask them to do the opposite.
                            For example, instead of telling your child never to be rude, tell them always to be polite.</p>
                      </div>
                </div>
              </div>
            <div class="col-md-3 d-flex services align-self-stretch pb-4 px-4 ftco-animate bg-tertiary">
                <div class="media block-6 d-block text-center">
                      <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-reading"></span>
                      </div>
                      <div class="media-body p-2 mt-3">
                        <h3 class="heading">Montessori</h3>
                        <p>A great education begins with a great kindergarten experience, so now we have a motor skills programs with separates sessions in the schedule. P re-kindergartners benefit from experiences that support the development of fine motor skills in the hands and fingers. Children should have strength and dexterity in their hands and fingers before being asked to manipulate a pencil on paper.</p>
                      </div>
                </div>
            </div>
              <div class="col-md-3 d-flex services align-self-stretch pb-4 px-4 ftco-animate bg-fifth">
                <div class="media block-6 d-block text-center">
                      <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-books"></span>
                      </div>
                      <div class="media-body p-2 mt-3">
                        <h3 class="heading">Meditation</h3>
                        <p>This is like a course that will make a great results with them, and match smarter.
                            according to yogic science, it takes 40 days to fully develop a new health-remoting habit or drop any negative destrcutive habit, Practice Yoga every day for 40 days straight and break through any limiting beliefs that block you from experiencing your total Radiant self!</p>
                      </div>
                </div>
              </div>
              <div class="col-md-3 d-flex services align-self-stretch pb-4 px-4 ftco-animate bg-quarternary">
                <div class="media block-6 d-block text-center">
                      <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-diploma"></span>
                      </div>
                     <div class="media-body p-2 mt-3">
                        <h3 class="heading">Sports Acadmic</h3>
                        <p>Physical exercise is good for mind, body and spirit. Furthermore, team sports are good for learning accountability, dedication, and leadership, among many other traits. Putting it all together by playing a sport is a winning combination.</p>
                      </div>
                </div>
              </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-no-pt ftc-no-pb">
    <div class="container">
        <div class="row">
            <div class="col-md-6 order-md-last wrap-about py-6 wrap-about bg-light">
                <div class="text px-4 ftco-animate">
                    <h2 class="mb-4">Welcome to Middle East Schools Official Website</h2>
                    <p>A high-quality education gives students a wider choice and better chances in college and university.
                        In these pages, you can learn more about MEIS, the curriculum, extracurricular activities, facilities, and requirements for admission, registration procedures, and other aspects of the schools that may be of interest to you.</p>
                </div>
            </div>
            <div class="col-md-6 order-md-last wrap-about py-6 wrap-about bg-light">
                <div class="text px-4 ftco-animate">
                    <h2 class="mb-4">Welcome message of the School Chairman</h2>
                    <p>Welcome message of the school Chairman: Thank you for taking an interest in Middle East International School (MIES) founded in 2013. We are very proud to offer our students, of all nationalities, a quality international education.
                        MEIS represents and develops the student's national identities and prepares them with the skills and knowledge needed to contribute in making their world a better place.
                        Looking forward to welcoming you in our horizon, seeking for brilliant future.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-intro" style="background-image: url({{url('public/design/site/images/bg_3.jpg') }});" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <h2>Teaching Your Child Some Good Manners</h2>
                <p class="mb-0">A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
            </div>
            <div class="col-md-3 d-flex align-items-center">
                {{--  <p class="mb-0"><a href="#" class="btn btn-secondary px-4 py-3">Take a Course</a></p>  --}}
            </div>
        </div>
    </div>
</section>
{{--  divisions  --}}
<section class="ftco-section">
    <div class="container">
        <div class="row">
        <div class="col-md-6 col-lg-4 ftco-animate">
            <div class="pricing-entry bg-light pb-4 text-center">
                <div>
                    <h3 class="mb-3">National Division</h3>
                    {{--  <p><span class="price">9.000 LE</span>  --}}
                </div>
                <div class="img" style="background-image: url({{ url('public/design/site/images/bg_1.jpg') }});"></div>
                <div class="px-4">
                    <p style="text-align:left;">The national division level has an important influence on the international dimensions through policy, funding, programs, and regulatory frameworks. Yet it is usually at the institutional level that the real process of internationalization is taking place.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4 ftco-animate">
            <div class="pricing-entry bg-light pb-4 text-center">
                <div>
                    <h3 class="mb-3">Semi-International Division</h3>
                    {{--  <p><span class="price">12.000 LE</span>  --}}
                </div>
                <div class="img" style="background-image: url({{ url('public/design/site/images/bg_2.jpg') }});"></div>
                <div class="px-4">
                    <ol style="text-align:left;">
                        <li>In Semi International division we have the International English curriculum</li>
                        <li>Conversation sessions.</li>
                        <li>Semi International teachers are allowed to attend Cambridge training courses.</li>
                        <li>Semi International students attend the physics and chemistry sessions in our well prepared laboratories.</li>
                        <li>Physical Education (PE) (Two sessions per week): Semi International Students are allowed to join the football. Academy for one of these sessions For the second sessions students are allowed to join the self defiance academy as well.</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4 ftco-animate">
            <div class="pricing-entry bg-light active pb-4 text-center">
                <div>
                    <h3 class="mb-3">British Division</h3>
                    {{--  <p><span class="price">20.000 LE</span>  --}}
                </div>
                <div class="img" style="background-image: url({{ url('public/design/site/images/bg_3.jpg') }});"></div>
                <div class="px-4">
                    <p style="text-align:left;">The world of higher education is changing and the world in which higher education plays a significant role is changing. The international dimension of higher education is becoming increasingly important. It is therefore timely to reexamine and update the conceptual frameworks underpinning the notion of inter-nationalization in light of today’s changes and challenges.</p>
                </div>
            </div>
        </div>

    </div>
    </div>
</section>
@endsection
@section('javascript')
<script src="{{url('public/design/site/js/jquery.min.js')}}"></script>
<script src="{{url('public/design/site/js/jquery-migrate-3.0.1.min.js')}}"></script>
@endsection
