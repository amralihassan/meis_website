@yield('javascript')
<script src="{{url('public/design/site/js/popper.min.js')}}"></script>
<script src="{{url('public/design/site/js/bootstrap.min.js')}}"></script>
<script src="{{url('public/design/site/js/jquery.easing.1.3.js')}}"></script>
<script src="{{url('public/design/site/js/jquery.waypoints.min.js')}}"></script>
<script src="{{url('public/design/site/js/jquery.stellar.min.js')}}"></script>
<script src="{{url('public/design/site/js/owl.carousel.min.js')}}"></script>
<script src="{{url('public/design/site/js/jquery.magnific-popup.min.js')}}"></script>
<script src="{{url('public/design/site/js/aos.js')}}"></script>
<script src="{{url('public/design/site/js/jquery.animateNumber.min.js')}}"></script>
<script src="{{url('public/design/site/js/scrollax.min.js')}}"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="{{url('public/design/site/js/google-map.js')}}"></script>
<script src="{{url('public/design/site/js/main.js')}}"></script>

