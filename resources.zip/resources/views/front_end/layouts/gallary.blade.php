<section class="ftco-gallery">
    <div class="container-wrap">
        <div class="row no-gutters">
                <div class="col-md-3 ftco-animate">
                    <a href="{{ url('public/design/site/images/course-1.jpg') }}" class="gallery image-popup img d-flex align-items-center" style="background-image: url({{ url('public/design/site/images/course-1.jpg') }});">
                        <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                    </a>
                </div>
                <div class="col-md-3 ftco-animate">
                    <a href="{{ url('public/design/site/images/image_2.jpg') }}" class="gallery image-popup img d-flex align-items-center" style="background-image: url({{ url('public/design/site/images/image_2.jpg') }});">
                        <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                    </a>
                </div>
                <div class="col-md-3 ftco-animate">
                    <a href="{{ url('public/design/site/images/image_3.jpg') }}" class="gallery image-popup img d-flex align-items-center" style="background-image: url({{ url('public/design/site/images/image_3.jpg') }});">
                        <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                    </a>
                </div>
                <div class="col-md-3 ftco-animate">
                    <a href="{{ url('public/design/site/images/image_4.jpg') }}" class="gallery image-popup img d-flex align-items-center" style="background-image: url({{ url('public/design/site/images/image_4.jpg') }});">
                        <div class="icon mb-4 d-flex align-items-center justify-content-center">
                        <span class="icon-instagram"></span>
                    </div>
                    </a>
                </div>
    </div>
    </div>
</section>