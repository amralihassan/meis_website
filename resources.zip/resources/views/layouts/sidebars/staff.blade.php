<div id="sidebar" class="sidebar responsive ace-save-state">
    <script type="text/javascript">
        try{ace.settings.loadState('sidebar')}catch(e){}
    </script>

    <div class="sidebar-shortcuts" id="sidebar-shortcuts">
        <div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">
            <button class="btn btn-success">
                <i class="ace-icon fa fa-signal"></i>
            </button>

            <button class="btn btn-info">
                <i class="ace-icon fa fa-pencil"></i>
            </button>

            <button class="btn btn-warning">
                <i class="ace-icon fa fa-users"></i>
            </button>

            <button class="btn btn-danger" onclick='location.href="{{staffURL()}}/hr/settings"'>
                <i class="ace-icon fa fa-cogs"></i>
            </button>
        </div>

        <div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">
            <span class="btn btn-success"></span>

            <span class="btn btn-info"></span>

            <span class="btn btn-warning"></span>

            <span class="btn btn-danger"></span>
        </div>
    </div><!-- /.sidebar-shortcuts -->

    <ul class="nav nav-list">
        <!-- Employees -->
        <li class="{{request()->segment(2) == 'employees'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-bar-chart-o"></i>
                <span class="menu-text">
                    {{trans('hr.employees')}}
                </span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu" style="display: {{request()->segment(2) == 'employees'?'block':'none'}};">
                <!-- index -->
                <li class="{{request()->segment(3) == 'data'?'active':''}}">
                    <a href="{{url('hr/employees/data')}}">					
                        <i class="menu-icon fa fa-caret-right"></i>{{trans('staff::employee.employeesData')}}</a>
                    <b class="arrow"></b>
                </li>			
                <!-- advanced search -->
                <li class="{{ request()->segment(3) == 'search'?'active':''}}">
                    <a href="{{url('hr/employees/search')}}">
                        <i class="menu-icon fa fa-caret-right"></i>{{trans('staff::employee.advancedSearch')}}</a>

                    <b class="arrow"></b>
                </li>	
                <!-- attachment -->
                <li class="{{ request()->segment(3) == 'attachments'?'active':''}}">
                    <a href="{{url('hr/employees/attachments')}}">
                        <i class="menu-icon fa fa-caret-right"></i>{{trans('staff::employee.attachments')}}</a>

                    <b class="arrow"></b>
                </li>	                			
                <!-- reports -->
                <li class="{{request()->segment(2) == 'employees' && request()->segment(3) == 'report'?'active':''}}">
                    <a href="{{url('employees/report')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.reports')}}
                    </a>

                    <b class="arrow"></b>
                </li>													
            </ul>
        </li>
        <!-- Attendance Logs -->	
        <li class="{{request()->segment(2) == 'attendance'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-clock-o"></i>
                <span class="menu-text">
                    {{trans('hr.attendance')}}
                </span>
                <b class="arrow fa fa-angle-down"></b>
            </a>
            <b class="arrow"></b>
            <ul class="submenu" style="display: {{request()->segment(2) == 'attendance'?'block':'none'}};">
                <!-- daily attendance -->
                <li class="{{request()->segment(3) == 'daily'?'active':''}}">
                    <a href="{{url('hr/attendance/daily')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.dailyAttendance')}}
                    </a>

                    <b class="arrow"></b>
                </li>
                <!-- attendance Logs -->
                <li class="{{request()->segment(3) == 'logs'?'active':''}}">
                    <a href="{{url('hr/attendance/logs')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.attendancelogs')}}
                    </a>

                    <b class="arrow"></b>
                </li>				
                <!-- import -->
                <li class="{{request()->segment(3) == 'import'?'active':''}}">
                    <a href="{{url('hr/attendance/import')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.importAttendnaceSheet')}}
                    </a>

                    <b class="arrow"></b>
                </li>																														
            </ul>
        </li>        
        <!-- Leave Request -->	
        <li class="{{request()->segment(2) == 'leave'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-arrow-left"></i>
                <span class="menu-text">
                    {{trans('hr.leaveRequests')}}
                </span>
                <b class="arrow fa fa-angle-down"></b>
            </a>
            <b class="arrow"></b>
            <ul class="submenu" style="display: {{request()->segment(2) == 'leave'?'block':'none'}};">
                <!-- all leave requests -->
                <li class="{{request()->segment(3) == 'requests'?'active':''}}">
                    <a href="{{url('hr/leave/requests')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('hr.leaveRequests')}}
                    </a>

                    <b class="arrow"></b>
                </li>
                <!-- confirm leave request -->
                <li class="{{request()->segment(3) == 'confirm'?'active':''}}">
                    <a href="{{url('hr/leave/confirm')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.confirmRequest')}}
                    </a>

                    <b class="arrow"></b>
                </li>				
																													
            </ul>
        </li>      
        <!-- deductions -->	      
        <li class="{{request()->segment(2) == 'deductions'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-gavel"></i>
                <span class="menu-text">
                    {{trans('hr.deductions')}}
                </span>
                <b class="arrow fa fa-angle-down"></b>
            </a>
            <b class="arrow"></b>
            <ul class="submenu" style="display: {{request()->segment(2) == 'deductions'?'block':'none'}};">
                <!-- all deductions -->
                <li class="{{request()->segment(2) == 'deductions' && request()->segment(3) == 'all'?'active':''}}">
                    <a href="{{url('hr/deductions/all')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('hr.deductions')}}
                    </a>

                    <b class="arrow"></b>
                </li>
                <!-- confirm deductions -->
                <li class="{{request()->segment(2) == 'deductions' && request()->segment(3) == 'confirm'?'active':''}}">
                    <a href="{{url('hr/deductions/confirm')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.confirmDedcution')}}
                    </a>

                    <b class="arrow"></b>
                </li>	
                <!-- confirm delete deductions or restore-->
                <li class="{{request()->segment(2) == 'deductions' && request()->segment(3) == 'deleted'?'active':''}}">
                    <a href="{{url('hr/deductions/deleted')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.deletedDeductions')}}
                    </a>

                    <b class="arrow"></b>
                </li>                			
																													
            </ul>
        </li>               	
        <!-- loans -->	
        <li class="{{request()->segment(3) == 'loans'?'active':''}}">
            <a href="{{url('hr/employee/loans')}}">
                <i class="menu-icon fa fa-minus-square-o"></i>
                <span class="menu-text">
                    {{trans('hr.loans')}}
                </span>
            </a>
        </li>			         			
        <!-- vacations -->	
        <li class="{{request()->segment(2) == 'vacation'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-umbrella"></i>
                <span class="menu-text">
                    {{trans('hr.vacations')}}
                </span>
                <b class="arrow fa fa-angle-down"></b>
            </a>
            <b class="arrow"></b>
            <ul class="submenu" style="display: {{request()->segment(2) == 'vacation'?'block':'none'}};">
                <!-- all vacations -->
                <li class="{{request()->segment(2) == 'vacation' && request()->segment(3) == 'all'?'active':''}}">
                    <a href="{{url('hr/vacation/all')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('hr.vacations')}}
                    </a>

                    <b class="arrow"></b>
                </li>
                <!-- confirm vacation -->
                <li class="{{request()->segment(2) == 'vacation' && request()->segment(3) == 'confirm'?'active':''}}">
                    <a href="{{url('hr/vacation/confirm')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.confirmVacation')}}
                    </a>

                    <b class="arrow"></b>
                </li>	
                <!-- confirm delete vacation or restore-->
                <li class="{{request()->segment(2) == 'vacation' && request()->segment(3) == 'deleted'?'active':''}}">
                    <a href="{{url('hr/vacation/deleted')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.deletedVacation')}}
                    </a>

                    <b class="arrow"></b>
                </li>                			
																													
            </ul>
        </li>  				
        <!--  Payroll -->	
        <li class="{{request()->segment(2) == 'payroll'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-money"></i>
                <span class="menu-text">
                    {{trans('hr.payroll')}}
                </span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu" style="display: {{request()->segment(2) == 'payroll'?'block':'none'}};">
                <!-- Process Payroll -->
                <li class="{{request()->segment(3) == 'process'?'active':''}}">
                    <a href="{{url('hr/payroll/process')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.processPayroll')}}
                    </a>
                    <b class="arrow"></b>
                </li>                                 
                <!-- temporary components -->	
                <li class="{{request()->segment(3) == 'temporary_compoent'?'active':''}}">
                    <a href="{{url('hr/payroll/temporary_compoent/show/temporary')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.temporaryComponent')}}
                    </a>
                    <b class="arrow"></b>
                </li>                  
                     
                <!-- fixed components -->	
                <li class="{{request()->segment(3) == 'fixed_component'?'active':''}}">
                    <a href="{{url('hr/payroll/fixed_component/show_fixed')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.fixedComponents')}}
                    </a>
                    <b class="arrow"></b>
                </li>   
                <!-- reports -->	
                <li class="{{request()->segment(3) == 'payrol_reports'?'active':''}}">
                    <a href="{{url('hr/payroll/payrol_reports')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('staff::employee.reports')}}
                    </a>
                    <b class="arrow"></b>
                </li>                                                  
            </ul>
        </li>	
        <!--  Training -->	
        <li class="{{request()->segment(3) == 'training'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-certificate"></i>
                <span class="menu-text">
                    {{trans('hr.training')}}
                </span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu" style="display: {{request()->segment(3) == 'trainees' || request()->segment(3) == 'training'?'block':'none'}};">
                <!-- training -->
                <li class="{{request()->segment(4) == 'training'?'active':''}}">
                    <a href="{{url('hr/employee/training/training')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('admin.training')}}
                    </a>

                    <b class="arrow"></b>
                </li>
                <!-- The trainees -->
                <li class="{{request()->segment(4) == 'trainees'?'active':''}}">
                    <a href="{{url('hr/employee/training/trainees')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('admin.trainees')}}
                    </a>

                    <b class="arrow"></b>
                </li>	
                                        
            </ul>
        </li>        																																			
        <!-- recruitment -->	
        <li class="{{request()->segment(2) == 'recruitment'?'active':''}}">
            <a href="#" class="dropdown-toggle">
                <i class="menu-icon fa fa-tasks"></i>
                <span class="menu-text">
                    {{trans('hr.recruitment')}}
                </span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu" style="display: {{request()->segment(2) == 'recruitment' ?'block':'none'}};">
                <!-- vacancies -->
                <li class="{{request()->segment(3) == 'vacancies'?'active':''}}">
                    <a href="{{url('hr/recruitment/vacancies')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('admin.vacancies')}}
                    </a>

                    <b class="arrow"></b>
                </li>
                <!-- applications -->
                <li class="{{request()->segment(3) == 'employee_application'?'active':''}}">
                    <a href="{{url('hr/recruitment/employee_application')}}">
                        <i class="menu-icon fa fa-caret-right"></i>
                        {{trans('admin.employeeApplication')}}
                    </a>

                    <b class="arrow"></b>
                </li>								
            </ul>
        </li>			 

    </ul><!-- /.nav-list -->

    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>
</div>