<div id="navbar" class="navbar navbar-default ace-save-state">
    <div class="navbar-container ace-save-state" id="navbar-container">
        <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
            <span class="sr-only">Toggle sidebar</span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>
        </button>

        <div class="navbar-header pull-left">
            <a href="{{aurl()}}" class="navbar-brand">
                <small>
                    {{trans('admin.systemShourtName')}}
                </small>
            </a>
        </div>

        <div class="navbar-buttons navbar-header pull-right" role="navigation">
            <ul class="nav ace-nav">
                <li class="purple dropdown-modal">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#" id="count">
                        <i class="ace-icon fa fa-bell icon-animated-bell"></i>                       
                            <span class="badge badge-important"></span>                                             
                    </a>

                    <ul class="dropdown-menu-right dropdown-navbar navbar-pink dropdown-menu dropdown-caret dropdown-close">
                        <li class="dropdown-header" id="countTitle">
                            <i class="ace-icon fa fa-exclamation-triangle"></i>
                           {{ trans('admin.notifications') }}
                        </li>

                        <li class="dropdown-content">
                            <ul class="dropdown-menu dropdown-navbar navbar-pink" id="notifications">   
                         
                            </ul>
                        </li>

                        <li class="dropdown-footer" id="view">
                           
                        </li>     

                    </ul>
                </li>

                {{-- <li class="green dropdown-modal">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <i class="ace-icon fa fa-envelope icon-animated-vertical"></i>
                        <span class="badge badge-success">5</span>
                    </a>

                    <ul class="dropdown-menu-right dropdown-navbar dropdown-menu dropdown-caret dropdown-close">
                        <li class="dropdown-header">
                            <i class="ace-icon fa fa-envelope-o"></i>
                            5 Messages
                        </li>

                        <li class="dropdown-content">
                            <ul class="dropdown-menu dropdown-navbar">
                                <li>
                                    <a href="#" class="clearfix">
                                        <img src="{{url('/public/design/images/avatars/avatar.png')}}" class="msg-photo" alt="Alex's Avatar" />
                                        <span class="msg-body">
                                            <span class="msg-title">
                                                <span class="blue">Alex:</span>
                                                Ciao sociis natoque penatibus et auctor ...
                                            </span>

                                            <span class="msg-time">
                                                <i class="ace-icon fa fa-clock-o"></i>
                                                <span>a moment ago</span>
                                            </span>
                                        </span>
                                    </a>
                                </li>

                                <li>
                                    <a href="#" class="clearfix">
                                        <img src="{{url('/public/design/images/avatars/avatar3.png')}}" class="msg-photo" alt="Susan's Avatar" />
                                        <span class="msg-body">
                                            <span class="msg-title">
                                                <span class="blue">Susan:</span>
                                                Vestibulum id ligula porta felis euismod ...
                                            </span>

                                            <span class="msg-time">
                                                <i class="ace-icon fa fa-clock-o"></i>
                                                <span>20 minutes ago</span>
                                            </span>
                                        </span>
                                    </a>
                                </li>

                                <li>
                                    <a href="#" class="clearfix">
                                        <img src="{{url('/public/design/images/avatars/avatar4.png')}}" class="msg-photo" alt="Bob's Avatar" />
                                        <span class="msg-body">
                                            <span class="msg-title">
                                                <span class="blue">Bob:</span>
                                                Nullam quis risus eget urna mollis ornare ...
                                            </span>

                                            <span class="msg-time">
                                                <i class="ace-icon fa fa-clock-o"></i>
                                                <span>3:15 pm</span>
                                            </span>
                                        </span>
                                    </a>
                                </li>

                                <li>
                                    <a href="#" class="clearfix">
                                        <img src="{{url('/public/design/images/avatars/avatar2.png')}}" class="msg-photo" alt="Kate's Avatar" />
                                        <span class="msg-body">
                                            <span class="msg-title">
                                                <span class="blue">Kate:</span>
                                                Ciao sociis natoque eget urna mollis ornare ...
                                            </span>

                                            <span class="msg-time">
                                                <i class="ace-icon fa fa-clock-o"></i>
                                                <span>1:33 pm</span>
                                            </span>
                                        </span>
                                    </a>
                                </li>

                                <li>
                                    <a href="#" class="clearfix">
                                        <img src="{{url('/public/design/images/avatars/avatar5.png')}}" class="msg-photo" alt="Fred's Avatar" />
                                        <span class="msg-body">
                                            <span class="msg-title">
                                                <span class="blue">Fred:</span>
                                                Vestibulum id penatibus et auctor  ...
                                            </span>

                                            <span class="msg-time">
                                                <i class="ace-icon fa fa-clock-o"></i>
                                                <span>10:09 am</span>
                                            </span>
                                        </span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <li class="dropdown-footer">
                            <a href="inbox.html">
                                See all messages
                                <i class="ace-icon fa fa-arrow-right"></i>
                            </a>
                        </li>
                    </ul>
                </li> --}}
                <!-- departments -->
                <li class="grey dropdown-modal">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                        {{trans('admin.departments')}}                    
                        <i class="ace-icon fa fa-caret-down"></i>
                    </a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                        <!-- hr -->
                        <li>
                            <a href="{{route('staff')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                {{trans('admin.humanResource')}}
                            </a>
                        </li>	
                        <!-- hr -->
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                {{trans('admission::admission.admissionDepartment')}}
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                مكتب الاستقبال
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                العلاقات العامة
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                شئون الطلاب
                            </a>
                        </li> 
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                حركة السيارات
                            </a>
                        </li>  
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                الحسابات
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                المكتبة
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                الكنترول المدرسي
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                العيادة
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                المخازن
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                الجدول المدرسي
                            </a>
                        </li>
                        <li>
                            <a href="{{route('admission')}}">
                                <i class="ace-icon fa fa-folder-o"></i>
                                سجل المكالمات
                            </a>
                        </li>                     	                        
                    </ul>
                </li>	
                <!-- end departments -->
                <li class="light-blue dropdown-modal">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                        <img class="nav-user-photo" src="{{asset('public/images/imagesProfile/'.authInfo()->imageProfile)}}" alt="Jason's Photo" />
                        <span class="user-info">
                            <small>{{trans('admin.welcome')}},</small>
                            {{adminAuth()->user()->name}}
                        </span>

                        <i class="ace-icon fa fa-caret-down"></i>
                    </a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                        <!-- website -->
                        <li>
                            <a href="{{url('/')}}">
                                <i class="ace-icon fa fa-globe"></i>
                                {{trans('admin.website')}}
                            </a>
                        </li>                                                             
                        <!-- settings -->
                        <li>
                            <a href="{{aurl('setting')}}">
                                <i class="ace-icon fa fa-cog"></i>
                                {{trans('admin.settings')}}
                            </a>
                        </li>
                        <!-- users accounts -->
                        <li>
                            <a href="{{aurl('admins')}}">
                                <i class="ace-icon fa fa-users"></i>
                                {{trans('admin.usersAccounts')}}
                            </a>
                        </li>
                        {{-- loginlogs --}}
                        <li>
                            <a href="{{aurl('loginlogs')}}">
                                <i class="ace-icon fa fa-sign-in"></i>
                                {{trans('admin.loginLogs')}}
                            </a>
                        </li>	
                        {{-- history --}}
                        <li>
                            <a href="{{aurl('history')}}">
                                <i class="ace-icon fa fa-history"></i>
                                {{trans('admin.history')}}
                            </a>
                        </li>
                        <!-- roles -->
                        <li>
                            <a href="#">
                                <i class="ace-icon fa fa-eye"></i>
                                {{trans('admin.permissions')}}
                            </a>
                        </li>	
                        <li>
                            <a href="{{aurl('lang/en')}}">
                                <i class="ace-icon fa fa-language"></i>
                                English
                            </a>
                        </li>
                        <li>
                            <a href="{{aurl('lang/ar')}}">
                                <i class="ace-icon fa fa-language"></i>
                                العربية
                            </a>
                        </li>																
                        <li class="divider"></li>
                        {{-- profile --}}
                        <li>
                            <a href="{{aurl('show_profile/'.authInfo()->id)}}">
                                <i class="ace-icon fa fa-user"></i>
                                {{trans('admin.profile')}}
                            </a>
                        </li>     
                        {{-- change password --}}
                        <li>
                            <a href="{{aurl('change/password')}}">
                                <i class="ace-icon fa fa-unlock-alt"></i>
                                {{trans('admin.changePassword')}}
                            </a>
                        </li>    
                        {{-- leave request --}}
                        <li>
                            <a href="{{url('hr/user/permission')}}">
                                <i class="ace-icon fa fa-briefcase"></i>
                                {{trans('staff::employee.leaveRequests')}}
                            </a>
                        </li>  
                        {{-- loans --}}
                        <li>
                            <a href="{{url('hr/user/all/loans')}}">
                                <i class="ace-icon fa fa-minus-square-o"></i>
                                {{trans('staff::employee.loans')}}
                            </a>
                        </li>  
                        {{-- deductions --}}
                        <li>
                            <a href="{{url('hr/user/dedcutions')}}">
                                <i class="ace-icon fa fa-gavel"></i>
                                {{trans('staff::employee.deductions')}}
                            </a>
                        </li>     
                        {{-- attendance --}}
                        <li>
                            <a href="{{url('hr/user/my/attendance')}}">
                                <i class="ace-icon fa fa-clock-o"></i>
                                {{trans('staff::employee.attendance')}}
                            </a>
                        </li>                                                                       
                        <li class="divider"></li>
                        <li>
                            <a href="{{aurl('logout')}}">
                                <i class="ace-icon fa fa-power-off"></i>
                                {{trans('admin.logout')}}
                            </a>
                        </li>
                    </ul>
                </li>
                        
            </ul>
        </div>
    </div><!-- /.navbar-container -->
</div>

