                    "oLanguage": {
                        "sProcessing": 	"{{trans('admin.sProcessing')}}",
                        "sLengthMenu": 	"{{trans('admin.sLengthMenu')}}",
                        "sZeroRecords": "{{trans('admin.sZeroRecords')}}",
                        "sEmptyTable": 	"{{trans('admin.sEmptyTable')}}",
                        "sInfo": 		"{{trans('admin.sInfo')}}",
                        "sInfoEmpty": 	"{{trans('admin.sInfoEmpty')}}",
                        "sInfoFiltered": "{{trans('admin.sInfoFiltered')}}",
                        "sInfoPostFix": "",
                        "sSearch": 		"{{trans('admin.sSearch')}}",
                        "sUrl": "",
                        "sInfoThousands": ",",
                        
                        "oPaginate": {
                            "sFirst": "{{trans('admin.sFirst')}}",
                            "sLast": "{{trans('admin.sLast')}}",
                            "sNext": "{{trans('admin.sNext')}}",
                            "sPrevious": "{{trans('admin.sPrevious')}}"
                        },
                        "oAria": {
                            "sSortAscending": "{{trans('admin.sSortAscending')}}",
                            "sSortDescending": "{{trans('admin.sSortDescending')}}"
                        }
                    }
                    ,
                    select: {
                            style: 'multi'
                        }	